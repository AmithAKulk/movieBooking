package com.moviebooking;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SeatBooking extends HttpServlet {


public void doGet(HttpServletRequest req,HttpServletResponse resp) throws IOException{
//Accepting info from webpage
	String seat_type= req.getParameter("SEAT-TYPE");
	String no_of_seat=req.getParameter("NO-OF-SEAT");
	PrintWriter pWriter=resp.getWriter();
	//INFO FROM DATA BASE
	String db_seat1="Standard";
	String db_seat2="Premium";
	
	int seatCost_Standard=250;
	int seatCost_Premium=500;
	
	
if (seat_type.equals(db_seat1));{
		resp.getWriter().print("you have selected Standard type of seat");
		pWriter.println("you have selected Standard type of seat");
		resp.setContentType("text/html");
}
	if(seat_type.equals(db_seat2));
{
	resp.getWriter().print("You have selected Premium type of seat");
	pWriter.println("You have selected Premium type of seat");
	    resp.setContentType("text/html");
}
	pWriter.close();
}
}
